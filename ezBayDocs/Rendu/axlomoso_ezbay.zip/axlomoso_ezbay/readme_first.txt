********************************************
* Notice d'installation de l'application ezBay
* Autheur : Axlomoso
* Date : 06-03-2006
********************************************

--------------------------------------------
-- CONTENU : 
--------------------------------------------
-	readme_first.txt : notice d�installation
-	datasource : contient le fichier de configuration de la �datasource� de ezBay
-	ezBayEAR.ear : application � d�ployer
-	requis : contient les fichiers du type librairies n�cessaires au fonctionnement du projet
-	sql : contient le script sql � �x�cuter pour ins�rer des enregistrements dans la base de donn�es
- 	src : contient les sources du projet


--------------------------------------------
-- NOTICE D 'INSTALLATION : (sous windows)
--------------------------------------------

-- Pr�requis : 
- disposer d'une installation � jour du SGBD MySql Server 5.0, fonctionnant en localhost, sur le port 3306
- disposer d'une installation � jour du serveur d'application JBoss 4.0.3


-- Proc�dure : 
1- Cr�ation de la base de donn�es : 
1.1- Cr�er une base de donn�es nomm�e "ezbayaxlomoso"
1.2- Cr�er un utilisateur "axlomoso", mot de passe "iloveejb", lui attribuer tous les droits sur la base de donn�es "ezbayaxlomoso"

2- Pr�paration du serveur d'application :
2.1- driver JDBC : jBoss arr�t�, copier le fichier /requis/mysql-connector-java-3.1.12-bin.jar dans <JBOSS-INSTALL-DIR>/server/<SERVER_NAME>/lib
2.2- configuration de la dataSource : copier le fichier /datasource/mysql-ds.xml dans <JBOSS-INSTALL-DIR>/server/<SERVER_NAME>/deploy

3- D�ploiement de l'application : 
3.1- D�ploiement : copier le r�pertoire /ezBayEAR.ear dans <JBOSS-INSTALL-DIR>/server/<SERVER_NAME>/deploy

4- Lancement : 
4.1- Lancer Jboss : executer <JBOSS-INSTALL-DIR>/bin/run.bat

Une fois jBoss lanc�, 
5- Cr�ation du jeu de donn�es : 
5.1- Executer le script /sql/ezbayFinal.sql dans mysql (utiliser un outil d'administration du type mysql_Query_browser)

6- Acc�s au client web : 
6.1- Lancer votre navigateur pr�f�r� (de pr�f�rence firefox...)
6.2- Taper l'adresse http://localhost:8080/ezBayWeb (remarque : si le port http:// par d�faut de jboss est bien 8080)

Enjoy...

6bis- Execution des tests unitaires : JUnitEE
6bis.1- Lancer votre navigateur pr�f�r� (de pr�f�rence firefox...)
6bis.2- Taper l'adresse http://localhost:8080/ezBayWeb/test.html (remarque : si le port http:// par d�faut de jboss est bien 8080)

